<h2>Panel de Aprendiz</h2>
<p>Bienvenido {{ Auth::user()->nombre }}</p>
