<h2>Panel de Instructor</h2>
<p>Bienvenido {{ Auth::user()->nombre }}</p>
