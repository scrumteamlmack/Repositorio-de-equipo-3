<h2>Panel de Guardia de Seguridad</h2>
<p>Bienvenido {{ Auth::user()->nombre }}</p>
