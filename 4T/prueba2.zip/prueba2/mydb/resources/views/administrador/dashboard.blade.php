<h2>Panel de Administrador</h2>
<p>Bienvenido {{ Auth::user()->nombre }}</p>
